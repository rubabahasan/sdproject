<!--Header HTML code from E-Shopper Template-->
{{asset('css/name.css')}}
{{url('products')}}

@yield('content')

<!--Footer HTML code from E-Shopper Template-->