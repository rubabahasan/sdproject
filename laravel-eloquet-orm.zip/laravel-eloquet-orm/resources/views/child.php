@extends('layouts.layout')

@section('content')

<!--HTML code from E-Shopper Template-->
@include('shared.sidebar')
<!--HTML code from E-Shopper Template-->

@endsection